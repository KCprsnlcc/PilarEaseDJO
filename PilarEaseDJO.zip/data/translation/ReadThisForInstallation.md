### Instructions to Run the Script
Copy and Paste it in terminal!!!

1. **Activate the Virtual Environment**:
    .venv\Scripts\activate

2. **Run Your Script**:
    python data-translation.py